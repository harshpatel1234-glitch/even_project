from django.shortcuts import get_object_or_404, render
from django.http import HttpResponse, HttpResponseForbidden
from .models import Student
from .forms import StudentForm


def home(request):
    return HttpResponse(
        "Django is running 🚀<br>"
        "Try /edit/2/ or /edit/4/"
    )


def edit_student(request, id):
    student = get_object_or_404(Student, id=id)

    # ❌ Block ODD ID
    if student.id % 2 != 0:
        return HttpResponseForbidden("❌ You can edit only EVEN ID records")

    # ✅ Allow EVEN ID
    if request.method == "POST":
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return HttpResponse("✅ Updated Successfully")
    else:
        form = StudentForm(instance=student)

    return render(request, "edit_student.html", {"form": form})
