from django.urls import path
from .views import edit_student, home

urlpatterns = [
    path('', home),
    path('edit/<int:id>/', edit_student, name='edit_student'),
]
